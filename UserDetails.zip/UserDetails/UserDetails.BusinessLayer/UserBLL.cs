﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserDetails.BusinessObjects;
using UserDetails.DataLayer;
using UserDetails.Utilities;

namespace UserDetails.BusinessLayer
{
    public partial class UserBLL
    {
        public UserBLL()
        {

        }  

        public DataTable GetAllUsers()
        {
            DataTable dtusers = new UserDAL().GetUsers();
            return dtusers;
        }

        public DataTable GetUserByUserId(int usrID)
        {
            DataTable dtusers = new UserDAL().GetUserByUserId(usrID);
            return dtusers;
        }

        public void DeleteUserByUserId(int usrID)
        {
            new UserDAL().DeleteUserByUserId(usrID);
        }

        public int SaveUser(UserBO objUserBO)
        {
            return new UserDAL().SaveUser(objUserBO);
        }

        public int UpdateUser(UserBO objUserBO)
        {
            return new UserDAL().UpdateUser(objUserBO);
        }
    }
}
