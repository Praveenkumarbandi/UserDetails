﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDetails.Utilities
{
    public abstract class DataAccessComponent
    {
        protected DbConnection _internalConnection;
        protected DbTransaction _internalTransaction = null;
        protected bool _autoCommitOrRollBack = true;

        public DbConnection InternalConnection
        {
            get
            {
                return _internalConnection;
            }
            set
            {
                _internalConnection = value;
            }
        }

        public DbTransaction InternalTransaction
        {
            get
            {
                return _internalTransaction;
            }
            set
            {
                _internalTransaction = value;
            }
        }

        public bool AutoCommitOrRollBack
        {
            get
            {
                return _autoCommitOrRollBack;
            }
            set
            {
                _autoCommitOrRollBack = value;
            }
        }

        private static SqlConnection connection;

        /// <value>
        /// Internal method to get and set the connection information to the <seealso>ConnectionClass</seealso>
        /// </value>
        protected static SqlConnection DBConnection
        {
            get { return new SqlConnection(ConnectionString); }
            set { connection = value; }
        }

        /// <value>
        /// Private method to get the connection string.
        /// </value>
        protected static string ConnectionString
        {
            get { return DBConstants.Constants.CONNECTION_STRING; }
        }

        /// <summary>
        /// Protected Method to get connection string based on connection name.
        /// </summary>
        /// <param name="strValue">Contains Connection name to get the connection string</param>
        /// <returns>Returns connection string based on name of the connection.</returns>
        protected static string GetConnectionString(string strValue)
        {
            return DBConstants.Constants.GetConnectionString(strValue);
        }

        /// <summary>
        /// Protected Method to get sqlconnection based on connection name.
        /// </summary>
        /// <param name="strValue">Contains Connection name to get the connection string</param>
        /// <returns>Returns sqlconnection string based on name of the connection.</returns>
        //protected static SqlConnection GetDBConnection(string strValue)
        //{
        //    string strConnectionString = GetConnectionString(strValue);
        //    return new SqlConnection(strConnectionString);
        //}
    }
}
