﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDetails.Utilities
{
    internal class DBConstants
    {
        /// <summary>
        /// This class holds the database connection string, database related constants etc.    
        /// </summary>
        internal class Constants
        {
            public static string CONNECTION_STRING = ConfigurationSettings.AppSettings["connectionString"];

            public static string GetConnectionString(string strConnectionName)
            {
                return ConfigurationSettings.AppSettings[strConnectionName];
            }
        }
    }
}
