﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDetails.Utilities
{
    public class DBExecute : DataAccessComponent
    {
        /// <summary>
        /// Method for executing a sql command using the 
        /// ConnectionClass connection and returns a dataset
        /// </summary>
        /// <param name="objValue">Sql command value that contains command text and command type information.</param>
        /// <returns><c>DataSet</c>, result of the command executed.</returns>
        /// <c>Version 1.0</c>
        public static DataSet ExecuteDataset(SqlCommand objValue)
        {
            DataSet ds = new DataSet();
            objValue.Connection = DataAccessComponent.DBConnection;
            SqlDataAdapter da = new SqlDataAdapter(objValue);
            da.Fill(ds);
            return ds;
        }

        public static DataTable ExecuteDataTable(SqlCommand objValue)
        {
            DataTable dt = new DataTable();
            objValue.Connection = DataAccessComponent.DBConnection;
            SqlDataAdapter da = new SqlDataAdapter(objValue);
            da.Fill(dt);
            return dt;
        }

        public static void ExecuteNonQuery(SqlCommand objValue)
        {
            objValue.Connection = DataAccessComponent.DBConnection;
            objValue.Connection.Open();
            objValue.ExecuteNonQuery();
            objValue.Connection.Close();
        }

        /// <summary>
        /// Method for executing an sql command passed as argument and will return 
        /// the first row first column element of the returned result set
        /// </summary>
        /// <param name="objValue">Sql command value that contains command text and command type information.</param>
        /// <returns><c>object</c>, containing the first row first column value of the result obtained.</returns>
        public static object ExecuteScalar(SqlCommand objValue)
        {
            objValue.Connection = DataAccessComponent.DBConnection;
            objValue.Connection.Open();
            object returnValue;
            returnValue = objValue.ExecuteScalar();
            objValue.Connection.Close();
            return returnValue;
        }
    }
}
