﻿using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserDetails.BusinessObjects;
using UserDetails.Utilities;

namespace UserDetails.DataLayer
{
    public partial class UserDAL : DataAccessComponent
    {
        public UserDAL()
        {

        }

        /// <summary>
        /// It will get the total users.
        /// </summary>
        /// <returns>Get the total users of Dataset</returns>
        public DataTable GetUsers()
        {
            SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_User");
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@firstName", null);
            cmd.Parameters.AddWithValue("@middleName", null);
            cmd.Parameters.AddWithValue("@lastName", null);
            cmd.Parameters.AddWithValue("@email", null);
            cmd.Parameters.AddWithValue("@mobile", null);
            cmd.Parameters.AddWithValue("@address", null);
            cmd.Parameters.AddWithValue("@pincode", null);
            cmd.Parameters.AddWithValue("@state", null);
            cmd.Parameters.AddWithValue("@Query", 4);
            return DBExecute.ExecuteDataTable(cmd);
        }

        public DataTable GetUserByUserId(int userID)
        {
            SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_User");
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@userID", userID);
            cmd.Parameters.AddWithValue("@firstName", null);
            cmd.Parameters.AddWithValue("@middleName", null);
            cmd.Parameters.AddWithValue("@lastName", null);
            cmd.Parameters.AddWithValue("@email", null);
            cmd.Parameters.AddWithValue("@mobile", null);
            cmd.Parameters.AddWithValue("@address", null);
            cmd.Parameters.AddWithValue("@pincode", null);
            cmd.Parameters.AddWithValue("@state", null);
            cmd.Parameters.AddWithValue("@Query", 5);
            return DBExecute.ExecuteDataTable(cmd);
        }

        public void DeleteUserByUserId(int userID)
        {
            SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_User");
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@userID", userID);
            cmd.Parameters.AddWithValue("@firstName", null);
            cmd.Parameters.AddWithValue("@middleName", null);
            cmd.Parameters.AddWithValue("@lastName", null);
            cmd.Parameters.AddWithValue("@email", null);
            cmd.Parameters.AddWithValue("@mobile", null);
            cmd.Parameters.AddWithValue("@address", null);
            cmd.Parameters.AddWithValue("@pincode", null);
            cmd.Parameters.AddWithValue("@state", null);
            cmd.Parameters.AddWithValue("@Query", 3);
            DBExecute.ExecuteNonQuery(cmd);
        }

        /// <summary>
        /// Update user
        /// </summary>
        /// <param name="objUserBO"></param>
        /// <returns></returns>
        public int UpdateUser(UserBO objUserBO)
        {
            SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_User");
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@userID", objUserBO.UserId);
            cmd.Parameters.AddWithValue("@firstName", objUserBO.FirstName);
            cmd.Parameters.AddWithValue("@middleName", objUserBO.MiddleName);
            cmd.Parameters.AddWithValue("@lastName", objUserBO.LastName);
            cmd.Parameters.AddWithValue("@email", objUserBO.EMail);
            cmd.Parameters.AddWithValue("@mobile", objUserBO.Mobile);
            cmd.Parameters.AddWithValue("@address", objUserBO.Address);
            cmd.Parameters.AddWithValue("@pincode", objUserBO.FirstName);
            cmd.Parameters.AddWithValue("@state", objUserBO.State);
            cmd.Parameters.AddWithValue("@Query", 2);
            return Convert.ToInt32(DBExecute.ExecuteScalar(cmd));
        }

        /// <summary>
        /// Insert User
        /// </summary>
        /// <param name="objUserBO"></param>
        /// <returns></returns>
        public int SaveUser(UserBO objUserBO)
        {
            SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_User");
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@firstName", objUserBO.FirstName);
            cmd.Parameters.AddWithValue("@middleName", objUserBO.MiddleName);
            cmd.Parameters.AddWithValue("@lastName", objUserBO.LastName);
            cmd.Parameters.AddWithValue("@email", objUserBO.EMail);
            cmd.Parameters.AddWithValue("@mobile", objUserBO.Mobile);
            cmd.Parameters.AddWithValue("@address", objUserBO.Address);
            cmd.Parameters.AddWithValue("@pincode", objUserBO.PinCode);
            cmd.Parameters.AddWithValue("@state", objUserBO.State);
            cmd.Parameters.AddWithValue("@Query", 1);
            return Convert.ToInt32(DBExecute.ExecuteScalar(cmd));
        }
    }
}
