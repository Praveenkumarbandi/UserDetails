﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using UserDetails.BusinessObjects;
using UserDetails.Repository;
using UserDetails.Utilities;

namespace UserDetails.UI
{
    public partial class User : System.Web.UI.Page
    {
        public static DataTable dtAllUsers = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllUsers();
            }
        }

        private void GetAllUsers()
        {
            dtAllUsers = GetUsers();
        }

        private DataTable GetUsers()
        {
            DataTable dt = new DataTable();
            return dt = new UserRepository().GetUsers();
        }

        [WebMethod]
        public static string GetUserById(int userid)
        {
            string jsondata;
            DataTable dt = new DataTable();
            dt = new UserRepository().GetUserById(userid);
            return jsondata = Helper.DataTableToJSONWithJavaScriptSerializer(dt);
        }

        [WebMethod]
        public static void SaveUser(UserBO objUser) //Insert data in database  
        {
            new UserRepository().SaveUser(objUser);
        }

        [WebMethod]
        public static void UpdateUser(UserBO objUser) //update data in database  
        {
            new UserRepository().UpdateUser(objUser);
        }

        [WebMethod]
        public static void DeleteUser(int userid)
        {
            new UserRepository().DeleteUser(userid);
        }
    }
}