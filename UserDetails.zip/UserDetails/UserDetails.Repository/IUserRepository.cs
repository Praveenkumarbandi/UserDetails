﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserDetails.BusinessObjects;

namespace UserDetails.Repository
{
    public interface IUserRepository
    {
        DataTable GetUsers();
        DataTable GetUserById(int id);
        void SaveUser(UserBO user);
        void UpdateUser(UserBO user);
        void DeleteUser(int userId);     
    }
}
