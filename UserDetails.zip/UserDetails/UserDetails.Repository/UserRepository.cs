﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserDetails.BusinessLayer;
using UserDetails.BusinessObjects;

namespace UserDetails.Repository
{
    public class UserRepository : IUserRepository
    {
        public void DeleteUser(int userId)
        {
            new UserBLL().DeleteUserByUserId(userId);
        }

        public DataTable GetUserById(int id)
        {
            return new UserBLL().GetUserByUserId(id);
        }

        public void SaveUser(UserBO user)
        {
            new UserBLL().SaveUser(user);
        }

        public void UpdateUser(UserBO user)
        {
            new UserBLL().UpdateUser(user);
        }        

        public DataTable GetUsers()
        {
            return new UserBLL().GetAllUsers();
        }
    }
}
